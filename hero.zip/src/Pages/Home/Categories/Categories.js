import React from 'react';
import { useEffect } from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';


const Categories = () => {
    const [categories, setCategories] = useState([])
    const [data, setData] = useState([])
    useEffect(() => {
        fetch('services.json')
            .then(res => res.json())
            .then(data => setCategories(data))
    }, [])

    const handleToyota = () => {
        const toyota = categories.filter(categorie => categorie.brand === 'Toyota')
        return setData(toyota)

    }
    const handleHonda = () => {
        const honda = categories.filter(categorie => categorie.brand === 'Honda')
        return setData(honda)
    }
    const handleNissan = () => {
        const nissan = categories.filter(categorie => categorie.brand === 'Nissan')
        return setData(nissan)
    }


    console.log(categories)
    return (
        <div>
            {
                categories.length > 0 ?
                    <div className='grid lg:grid-cols-3 md:grid-cols-2 sm:grid-cols-1 gap-10'>
                        <div className="card w-96 bg-base-100 shadow-xl">
                            <figure className="px-10 pt-10">
                                <img src={categories[0]?.img} alt="Shoes" className="rounded-xl" />
                            </figure>
                            <div className="card-body items-center text-center">
                                <h2 className="card-title">{categories[0].brand}</h2>
                                <p>If a dog chews shoes whose shoes does he choose?</p>
                                <div className="card-actions">
                                    <Link to={`/catergorie/${categories[0]._id}`}><button onClick={handleToyota} className="btn btn-primary m-10">Toyota</button></Link>
                                </div>
                            </div>
                        </div>
                        <div className="card w-96 bg-base-100 shadow-xl">
                            <figure className="px-10 pt-10">
                                <img src={categories[2].img} alt="Shoes" className="rounded-xl" />
                            </figure>
                            <div className="card-body items-center text-center">
                                <h2 className="card-title">{categories[2].brand}</h2>
                                <p>If a dog chews shoes whose shoes does he choose?</p>
                                <div className="card-actions">
                                    <Link to={`/catergorie/${categories[2]._id}`}><button onClick={handleHonda} className="btn btn-primary m-10">Honda</button></Link>
                                </div>
                            </div>
                        </div>
                        <div className="card w-96 bg-base-100 shadow-xl">
                            <figure className="px-10 pt-10">
                                <img src={categories[4].img} alt="Shoes" className="rounded-xl" />
                            </figure>
                            <div className="card-body items-center text-center">
                                <h2 className="card-title">{categories[4].brand}</h2>
                                <p>If a dog chews shoes whose shoes does he choose?</p>
                                <div className="card-actions">
                                    <Link to={`/catergorie/${categories[4]._id}`}><button onClick={handleNissan} className="btn btn-primary m-10">Nissan</button></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                    :
                    null
            }
        </div>
    );
};

export default Categories;