import React, { useEffect, useState } from 'react';
import { useLoaderData } from 'react-router-dom';


const Categorie = () => {
    const [categories, setCategories] = useState([])
    const [data, setData] = useState([])
    useEffect(() => {
        fetch('services.json')
            .then(res => res.json())
            .then(data => console.log(data))
    }, [])
    // console.log(categories)
    return (
        <div>

        </div>
    );
};

export default Categorie;