import React, { useEffect, useState } from 'react';

const Trial = () => {
    const [categories, setCategories] = useState([])
    useEffect(() => {
        fetch('services.json')
            .then(res => res.json())
            .then(data => setCategories(data))
    }, [])
    console.log(categories)

    return (
        <div>
            <h1>Thsi si ytajslhl</h1>
        </div>
    );
};

export default Trial;