// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAv_6i917djzXhluYxq6QG-3l_Ik_g1i3s",
    authDomain: "hero-cars-16528.firebaseapp.com",
    projectId: "hero-cars-16528",
    storageBucket: "hero-cars-16528.appspot.com",
    messagingSenderId: "267925427502",
    appId: "1:267925427502:web:9d2a84b3af91dc8f2f16bf"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;